class WebSocketConnection {
  ws = null;
  reconnectAttempts = 0;
  maxReconnectAttempts = 10;
  reconnectDelay = 1e3;
  messageHandler = null;
  storage = null;
  reconnectTimer = null;
  pingInterval = null;
  isManualConnect = false;
  async connect(manual = false) {
    this.isManualConnect = manual;
    if (manual) {
      this.reconnectAttempts = 0;
      if (this.reconnectTimer) {
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = null;
      }
    }
    if (this.ws) {
      this.cleanup();
      if (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING) {
        this.ws.close();
      }
      this.ws = null;
    }
    const result = await chrome.storage.local.get([
      "token",
      "wsBaseUrl",
      "personaId"
    ]);
    this.storage = result;
    if (!this.storage.token) {
      console.log("[WebSocket] No token found, not connecting");
      return false;
    }
    const wsUrl = this.storage.wsBaseUrl || "wss://api.clawku.ai";
    const url = `${wsUrl}/browser/ws?token=${this.storage.token}`;
    return new Promise((resolve) => {
      let resolved = false;
      const safeResolve = (value) => {
        if (!resolved) {
          resolved = true;
          resolve(value);
        }
      };
      try {
        console.log("[WebSocket] Connecting to", wsUrl);
        this.ws = new WebSocket(url);
        this.ws.onopen = () => {
          console.log("[WebSocket] Connected");
          this.reconnectAttempts = 0;
          this.isManualConnect = false;
          this.startPing();
          this.updateBadge("connected");
          safeResolve(true);
        };
        this.ws.onmessage = (event) => {
          this.handleMessage(event.data);
        };
        this.ws.onclose = (event) => {
          console.log("[WebSocket] Closed:", event.code, event.reason);
          this.cleanup();
          this.updateBadge("disconnected");
          safeResolve(false);
          if (!this.isManualConnect) {
            this.scheduleReconnect();
          }
        };
        this.ws.onerror = (error) => {
          console.error("[WebSocket] Error:", error);
          this.updateBadge("error");
        };
      } catch (error) {
        console.error("[WebSocket] Connection error:", error);
        safeResolve(false);
      }
    });
  }
  handleMessage(data) {
    try {
      const message = JSON.parse(data);
      console.log("[WebSocket] Received:", message.type);
      if (message.type === "browser.job" && this.messageHandler) {
        this.messageHandler(message);
      } else if (message.type === "pong") {
      }
    } catch (error) {
      console.error("[WebSocket] Failed to parse message:", error);
    }
  }
  sendResult(payload) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      console.error("[WebSocket] Cannot send - not connected");
      return false;
    }
    const message = {
      type: "browser.result",
      payload
    };
    this.ws.send(JSON.stringify(message));
    console.log("[WebSocket] Sent result for job:", payload.jobId);
    return true;
  }
  startPing() {
    this.stopPing();
    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: "ping" }));
      }
    }, 3e4);
  }
  stopPing() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }
  cleanup() {
    this.stopPing();
    if (this.ws) {
      this.ws.onopen = null;
      this.ws.onmessage = null;
      this.ws.onclose = null;
      this.ws.onerror = null;
      this.ws = null;
    }
  }
  scheduleReconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
    }
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.log("[WebSocket] Max reconnect attempts reached");
      this.updateBadge("error");
      return;
    }
    const delay = Math.min(
      this.reconnectDelay * Math.pow(2, this.reconnectAttempts),
      6e4
    );
    this.reconnectAttempts++;
    console.log(
      `[WebSocket] Reconnecting in ${delay}ms (attempt ${this.reconnectAttempts})`
    );
    this.reconnectTimer = setTimeout(() => {
      this.connect();
    }, delay);
  }
  disconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    this.reconnectAttempts = this.maxReconnectAttempts;
    this.cleanup();
    if (this.ws) {
      this.ws.close();
    }
    this.updateBadge("disconnected");
  }
  setMessageHandler(handler) {
    this.messageHandler = handler;
  }
  isConnected() {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }
  updateBadge(status) {
    const colors = {
      connected: "#22c55e",
      // Green
      disconnected: "#f59e0b",
      // Yellow
      error: "#ef4444"
      // Red
    };
    const text = {
      connected: "ON",
      disconnected: "",
      error: "!"
    };
    chrome.action.setBadgeBackgroundColor({ color: colors[status] });
    chrome.action.setBadgeText({ text: text[status] });
  }
}
const wsConnection = new WebSocketConnection();

const DEFAULT_API_URL = "https://api.clawku.ai";
async function pair(code, apiBaseUrl) {
  const baseUrl = apiBaseUrl || DEFAULT_API_URL;
  try {
    const response = await fetch(`${baseUrl}/browser/pair`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ code })
    });
    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      return {
        success: false,
        error: error.message || `Pairing failed (${response.status})`
      };
    }
    const data = await response.json();
    const storage = {
      token: data.token,
      userId: data.userId,
      personaId: data.personaId,
      personaName: data.personaName,
      apiBaseUrl: baseUrl,
      wsBaseUrl: baseUrl.replace("https://", "wss://").replace("http://", "ws://"),
      pairedAt: Date.now()
    };
    await chrome.storage.local.set(storage);
    console.log("[Auth] Paired successfully with persona:", data.personaName);
    return { success: true };
  } catch (error) {
    console.error("[Auth] Pairing error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Network error"
    };
  }
}
async function disconnect() {
  const storage = await chrome.storage.local.get(["token", "apiBaseUrl"]);
  if (storage.token && storage.apiBaseUrl) {
    try {
      await fetch(`${storage.apiBaseUrl}/browser/disconnect`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${storage.token}`
        }
      });
    } catch (error) {
      console.error("[Auth] Disconnect API error:", error);
    }
  }
  await chrome.storage.local.clear();
  console.log("[Auth] Disconnected and cleared storage");
}
async function getStatus$1() {
  const storage = await chrome.storage.local.get([
    "token",
    "personaName",
    "pairedAt"
  ]);
  if (!storage.token) {
    return {
      paired: false,
      connected: false
    };
  }
  const wsStatus = await chrome.storage.local.get(["wsConnected"]);
  return {
    paired: true,
    connected: wsStatus.wsConnected === true,
    personaName: storage.personaName,
    lastSeen: storage.pairedAt
  };
}
async function getStoredCredentials() {
  const storage = await chrome.storage.local.get([
    "token",
    "userId",
    "personaId",
    "personaName",
    "apiBaseUrl",
    "wsBaseUrl",
    "pairedAt"
  ]);
  if (!storage.token) {
    return null;
  }
  return storage;
}

async function executeCommand(action, params2) {
  console.log("[Commands] Executing:", action, params2);
  try {
    switch (action) {
      case "status":
        return await getStatus();
      case "tabs":
        return await getTabs();
      case "open":
        return await openTab(params2);
      case "close":
        return await closeTab(params2);
      case "focus":
        return await focusTab(params2);
      case "navigate":
        return await navigateTab(params2);
      case "screenshot":
        return await takeScreenshot(params2);
      case "snapshot":
        return await getSnapshot(params2);
      case "console":
        return await getConsole(params2);
      case "act":
        return await executeAct(params2);
      case "click":
        return await executeContentAction("click", params2);
      case "type":
        return await executeContentAction("type", params2);
      case "press":
        return await executeContentAction("press", params2);
      case "hover":
        return await executeContentAction("hover", params2);
      case "scroll":
        return await executeContentAction("scroll", params2);
      case "select":
        return await executeContentAction("select", params2);
      case "start":
      case "stop":
        return {
          success: true,
          result: {
            ok: true,
            note: "Browser control via Clawku extension - browser is always running"
          }
        };
      case "profiles":
        return {
          success: true,
          result: {
            profiles: ["clawku-extension"],
            current: "clawku-extension",
            note: "Clawku extension controls your actual Chrome browser"
          }
        };
      case "pdf":
        return {
          success: false,
          error: "PDF export not supported via extension. Use screenshot instead."
        };
      case "upload":
        return {
          success: false,
          error: "File upload not supported via extension."
        };
      case "dialog":
        return {
          success: false,
          error: "Dialog handling not supported via extension."
        };
      default:
        return { success: false, error: `Unknown action: ${action}` };
    }
  } catch (error) {
    console.error("[Commands] Error:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : String(error)
    };
  }
}
async function executeAct(params2) {
  const request = params2.request;
  const kind = request?.kind || params2.kind;
  if (!kind) {
    return { success: false, error: 'act action requires "kind" parameter (click, type, scroll, etc.)' };
  }
  const actParams = {
    ...params2,
    ...request || {}
  };
  console.log("[Commands] Act:", kind, actParams);
  switch (kind) {
    case "click":
      return await executeContentAction("click", actParams);
    case "type":
      return await executeContentAction("type", actParams);
    case "press":
      return await executeContentAction("press", actParams);
    case "hover":
      return await executeContentAction("hover", actParams);
    case "scroll":
      return await executeContentAction("scroll", actParams);
    case "select":
      return await executeContentAction("select", actParams);
    case "drag":
      return await executeContentAction("drag", actParams);
    case "fill":
      return await executeFillForm(actParams);
    case "wait":
      return await executeWait(actParams);
    case "close":
      return await closeTab(actParams);
    case "resize":
      return {
        success: false,
        error: "Window resize not supported via extension"
      };
    case "evaluate":
      return await executeEvaluate(actParams);
    default:
      return { success: false, error: `Unknown act kind: ${kind}` };
  }
}
async function executeFillForm(params2) {
  if (!params2.fields || params2.fields.length === 0) {
    return { success: false, error: "fill action requires fields parameter" };
  }
  let tabId2 = params2.targetId ? typeof params2.targetId === "string" ? parseInt(params2.targetId, 10) : params2.targetId : void 0;
  if (!tabId2 || isNaN(tabId2)) {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    tabId2 = activeTab?.id;
  }
  if (!tabId2) {
    return { success: false, error: "No tab for fill action" };
  }
  const results2 = await chrome.scripting.executeScript({
    target: { tabId: tabId2 },
    func: fillFormFields,
    args: [params2.fields]
  });
  if (!results2 || results2.length === 0) {
    return { success: false, error: "Failed to execute fill" };
  }
  return results2[0].result;
}
function fillFormFields(fields) {
  try {
    for (const field of fields) {
      const selector = field.selector;
      const ref = field.ref;
      const value = field.value;
      let element = null;
      if (selector) {
        element = document.querySelector(selector);
      } else if (ref) {
        element = document.querySelector(`[data-ref="${ref}"]`);
      }
      if (element && (element instanceof HTMLInputElement || element instanceof HTMLTextAreaElement)) {
        element.value = value;
        element.dispatchEvent(new Event("input", { bubbles: true }));
        element.dispatchEvent(new Event("change", { bubbles: true }));
      }
    }
    return { success: true, result: { filled: fields.length } };
  } catch (error) {
    return { success: false, error: String(error) };
  }
}
async function executeWait(params2) {
  const timeMs = params2.timeMs || params2.timeoutMs || 1e3;
  await new Promise((resolve) => setTimeout(resolve, timeMs));
  if (params2.selector) {
    let tabId2 = params2.targetId ? typeof params2.targetId === "string" ? parseInt(params2.targetId, 10) : params2.targetId : void 0;
    if (!tabId2 || isNaN(tabId2)) {
      const [activeTab] = await chrome.tabs.query({
        active: true,
        currentWindow: true
      });
      tabId2 = activeTab?.id;
    }
    if (tabId2) {
      const results2 = await chrome.scripting.executeScript({
        target: { tabId: tabId2 },
        func: waitForSelector,
        args: [params2.selector, params2.timeoutMs || 1e4]
      });
      if (results2 && results2.length > 0) {
        return results2[0].result;
      }
    }
  }
  return { success: true, result: { waited: timeMs } };
}
function waitForSelector(selector, timeoutMs) {
  return new Promise((resolve) => {
    const startTime = Date.now();
    const check = () => {
      const element = document.querySelector(selector);
      if (element) {
        resolve({ success: true, result: { found: true, selector } });
        return;
      }
      if (Date.now() - startTime > timeoutMs) {
        resolve({ success: false, error: `Timeout waiting for ${selector}` });
        return;
      }
      requestAnimationFrame(check);
    };
    check();
  });
}
async function executeEvaluate(params) {
  if (!params.fn) {
    return { success: false, error: "evaluate action requires fn parameter" };
  }
  let tabId = params.targetId ? typeof params.targetId === "string" ? parseInt(params.targetId, 10) : params.targetId : void 0;
  if (!tabId || isNaN(tabId)) {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    tabId = activeTab?.id;
  }
  if (!tabId) {
    return { success: false, error: "No tab for evaluate" };
  }
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (fnString) => {
        try {
          const result = eval(fnString);
          return { success: true, result };
        } catch (error) {
          return { success: false, error: String(error) };
        }
      },
      args: [params.fn]
    });
    if (!results || results.length === 0) {
      return { success: false, error: "Failed to evaluate" };
    }
    return results[0].result;
  } catch (error) {
    return { success: false, error: String(error) };
  }
}
async function getStatus() {
  const tabs = await chrome.tabs.query({});
  return {
    success: true,
    result: {
      tabCount: tabs.length,
      extensionVersion: chrome.runtime.getManifest().version
    }
  };
}
async function getTabs() {
  const tabs = await chrome.tabs.query({});
  const tabList = tabs.map((tab) => ({
    id: tab.id,
    targetId: String(tab.id),
    // OpenClaw expects string targetId
    url: tab.url,
    title: tab.title,
    active: tab.active,
    windowId: tab.windowId,
    type: "page"
  }));
  return {
    success: true,
    result: { tabs: tabList }
  };
}
async function openTab(params2) {
  const url = params2.url || params2.targetUrl;
  if (!url) {
    return { success: false, error: "URL is required (url or targetUrl)" };
  }
  const tab = await chrome.tabs.create({ url, active: true });
  return {
    success: true,
    result: {
      ok: true,
      tabId: tab.id,
      targetId: String(tab.id),
      url: tab.url
    }
  };
}
async function closeTab(params2) {
  const tabId2 = params2.targetId ? typeof params2.targetId === "string" ? parseInt(params2.targetId, 10) : params2.targetId : void 0;
  if (tabId2 && !isNaN(tabId2)) {
    await chrome.tabs.remove(tabId2);
  } else {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    if (activeTab?.id) {
      await chrome.tabs.remove(activeTab.id);
    }
  }
  return { success: true, result: { closed: true } };
}
async function focusTab(params2) {
  if (!params2.targetId) {
    return { success: false, error: "Tab ID is required" };
  }
  const tabId2 = typeof params2.targetId === "string" ? parseInt(params2.targetId, 10) : params2.targetId;
  if (isNaN(tabId2)) {
    return { success: false, error: "Invalid tab ID" };
  }
  await chrome.tabs.update(tabId2, { active: true });
  const tab = await chrome.tabs.get(tabId2);
  if (tab.windowId) {
    await chrome.windows.update(tab.windowId, { focused: true });
  }
  return { success: true, result: { focused: params2.targetId } };
}
async function navigateTab(params2) {
  const url = params2.url || params2.targetUrl;
  if (!url) {
    return { success: false, error: "URL is required (url or targetUrl)" };
  }
  let tabId2 = params2.targetId ? typeof params2.targetId === "string" ? parseInt(params2.targetId, 10) : params2.targetId : void 0;
  if (!tabId2 || isNaN(tabId2)) {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    tabId2 = activeTab?.id;
  }
  if (!tabId2) {
    return { success: false, error: "No tab to navigate" };
  }
  await chrome.tabs.update(tabId2, { url });
  return {
    success: true,
    result: {
      ok: true,
      targetId: String(tabId2),
      url
    }
  };
}
async function takeScreenshot(params2) {
  const format = params2.format || "png";
  const quality = params2.quality || 90;
  let tabId2 = params2.targetId ? typeof params2.targetId === "string" ? parseInt(params2.targetId, 10) : params2.targetId : void 0;
  if (!tabId2 || isNaN(tabId2)) {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    tabId2 = activeTab?.id;
  }
  if (!tabId2) {
    return { success: false, error: "No tab to screenshot" };
  }
  const tab = await chrome.tabs.get(tabId2);
  if (!tab.windowId) {
    return { success: false, error: "Tab has no window" };
  }
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
    format,
    quality: format === "jpeg" ? quality : void 0
  });
  return {
    success: true,
    result: {
      dataUrl,
      format,
      tabId: tabId2,
      url: tab.url,
      title: tab.title
    }
  };
}
async function getSnapshot(params2) {
  let tabId2 = params2.targetId ? typeof params2.targetId === "string" ? parseInt(params2.targetId, 10) : params2.targetId : void 0;
  if (!tabId2 || isNaN(tabId2)) {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    tabId2 = activeTab?.id;
  }
  if (!tabId2) {
    return { success: false, error: "No tab to snapshot" };
  }
  const format = params2.snapshotFormat || "ai";
  const maxChars = params2.maxChars || 8e3;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId2 },
      files: ["content/content-script.js"]
    });
  } catch {
  }
  try {
    const response = await chrome.tabs.sendMessage(tabId2, {
      type: "GET_SNAPSHOT",
      payload: { format, maxChars }
    });
    if (!response || !response.success) {
      throw new Error(response?.error || "Snapshot failed");
    }
    const snapshotData = response.result;
    return {
      success: true,
      result: {
        url: snapshotData.url,
        title: snapshotData.title,
        snapshot: snapshotData.snapshot,
        format,
        targetId: String(tabId2),
        truncated: snapshotData.snapshot.endsWith("..."),
        stats: { refs: snapshotData.refCount || 0 }
      }
    };
  } catch {
    const results2 = await chrome.scripting.executeScript({
      target: { tabId: tabId2 },
      func: generatePageSnapshot,
      args: [format, maxChars]
    });
    if (!results2 || results2.length === 0) {
      return { success: false, error: "Failed to get snapshot" };
    }
    const snapshotData = results2[0].result;
    return {
      success: true,
      result: {
        ...snapshotData,
        targetId: String(tabId2),
        truncated: snapshotData.snapshot.endsWith("...")
      }
    };
  }
}
function generatePageSnapshot(format, maxChars) {
  const refs = /* @__PURE__ */ new Map();
  let refCounter = 0;
  function getElementRef(el) {
    const ref = `e${refCounter++}`;
    refs.set(ref, el);
    return ref;
  }
  function isInteractive(el) {
    const tag = el.tagName.toLowerCase();
    const role = el.getAttribute("role");
    const interactiveTags = [
      "a",
      "button",
      "input",
      "select",
      "textarea",
      "details",
      "summary"
    ];
    const interactiveRoles = [
      "button",
      "link",
      "checkbox",
      "radio",
      "textbox",
      "combobox",
      "menuitem",
      "tab"
    ];
    return interactiveTags.includes(tag) || role !== null && interactiveRoles.includes(role) || el.hasAttribute("onclick") || el.hasAttribute("tabindex");
  }
  function getElementText(el) {
    let text = "";
    for (const child of el.childNodes) {
      if (child.nodeType === Node.TEXT_NODE) {
        text += child.textContent?.trim() || "";
      }
    }
    return text.slice(0, 100);
  }
  function serializeElement(el, depth = 0) {
    if (depth > 10) return "";
    const indent = "  ".repeat(depth);
    const tag = el.tagName.toLowerCase();
    const style = window.getComputedStyle(el);
    if (style.display === "none" || style.visibility === "hidden") {
      return "";
    }
    if (["script", "style", "noscript", "svg", "path"].includes(tag)) {
      return "";
    }
    let line = `${indent}[${tag}]`;
    if (isInteractive(el)) {
      const ref = getElementRef(el);
      line += ` (${ref})`;
    }
    const id = el.getAttribute("id");
    el.getAttribute("class");
    const href = el.getAttribute("href");
    el.getAttribute("src");
    const type = el.getAttribute("type");
    const placeholder = el.getAttribute("placeholder");
    const ariaLabel = el.getAttribute("aria-label");
    const value = el.value;
    if (id) line += ` id="${id}"`;
    if (ariaLabel) line += ` "${ariaLabel}"`;
    if (href) line += ` href="${href.slice(0, 50)}"`;
    if (type) line += ` type="${type}"`;
    if (placeholder) line += ` placeholder="${placeholder}"`;
    if (value && tag === "input") line += ` value="${value.slice(0, 30)}"`;
    const text = getElementText(el);
    if (text) {
      line += ` "${text}"`;
    }
    let result2 = line + "\n";
    for (const child of el.children) {
      result2 += serializeElement(child, depth + 1);
    }
    return result2;
  }
  const snapshot = serializeElement(document.body);
  const truncated = snapshot.length > maxChars ? snapshot.slice(0, maxChars) + "\n..." : snapshot;
  return {
    url: window.location.href,
    title: document.title,
    snapshot: truncated,
    format
  };
}
async function executeContentAction(action, params2) {
  let tabId2 = params2.targetId ? typeof params2.targetId === "string" ? parseInt(params2.targetId, 10) : params2.targetId : void 0;
  if (!tabId2 || isNaN(tabId2)) {
    const [activeTab] = await chrome.tabs.query({
      active: true,
      currentWindow: true
    });
    tabId2 = activeTab?.id;
  }
  if (!tabId2) {
    return { success: false, error: "No tab for action" };
  }
  try {
    const response = await chrome.tabs.sendMessage(tabId2, {
      type: "EXECUTE_ACTION",
      payload: { action, params: params2 }
    });
    return response;
  } catch (error) {
    await chrome.scripting.executeScript({
      target: { tabId: tabId2 },
      files: ["content/content-script.js"]
    });
    const response = await chrome.tabs.sendMessage(tabId2, {
      type: "EXECUTE_ACTION",
      payload: { action, params: params2 }
    });
    return response;
  }
}
async function getConsole(params2) {
  return {
    success: true,
    result: {
      messages: [],
      note: "Console capture requires page injection"
    }
  };
}
function createResultPayload(jobId, nonce, result2) {
  return {
    jobId,
    status: result2.success ? "COMPLETED" : "FAILED",
    result: result2.result,
    errorText: result2.error,
    nonce,
    issuedAt: Date.now()
  };
}

console.log("[ServiceWorker] Starting Clawku Browser Extension");
wsConnection.setMessageHandler(async (message) => {
  const { jobId, action, params, nonce, expiresAt } = message.payload;
  console.log("[ServiceWorker] Received job:", jobId, action);
  if (Date.now() > expiresAt) {
    console.log("[ServiceWorker] Job expired:", jobId);
    const result2 = createResultPayload(jobId, nonce, {
      success: false,
      error: "Job expired"
    });
    wsConnection.sendResult(result2);
    return;
  }
  const commandResult = await executeCommand(action, params);
  const result = createResultPayload(jobId, nonce, commandResult);
  wsConnection.sendResult(result);
  showActivityBadge();
});
function showActivityBadge() {
  chrome.action.setBadgeText({ text: "..." });
  chrome.action.setBadgeBackgroundColor({ color: "#3b82f6" });
  setTimeout(() => {
    if (wsConnection.isConnected()) {
      chrome.action.setBadgeText({ text: "ON" });
      chrome.action.setBadgeBackgroundColor({ color: "#22c55e" });
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
  }, 500);
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("[ServiceWorker] Popup message:", message.type);
  (async () => {
    switch (message.type) {
      case "GET_STATUS": {
        const status = await getStatus$1();
        status.connected = wsConnection.isConnected();
        sendResponse(status);
        break;
      }
      case "PAIR": {
        if (!message.payload?.code) {
          sendResponse({ success: false, error: "No code provided" });
          return;
        }
        const result = await pair(
          message.payload.code,
          message.payload.apiBaseUrl
        );
        if (result.success) {
          await wsConnection.connect();
          await chrome.storage.local.set({ wsConnected: wsConnection.isConnected() });
        }
        sendResponse(result);
        break;
      }
      case "DISCONNECT": {
        wsConnection.disconnect();
        await disconnect();
        await chrome.storage.local.set({ wsConnected: false });
        sendResponse({ success: true });
        break;
      }
      case "RECONNECT": {
        const creds = await getStoredCredentials();
        if (!creds) {
          sendResponse({ success: false, error: "Not paired" });
          return;
        }
        const connected = await wsConnection.connect(true);
        await chrome.storage.local.set({ wsConnected: connected });
        sendResponse({ success: connected, error: connected ? void 0 : "Connection failed" });
        break;
      }
      default:
        sendResponse({ success: false, error: "Unknown message type" });
    }
  })();
  return true;
});
chrome.runtime.onStartup.addListener(async () => {
  console.log("[ServiceWorker] Browser startup - checking credentials");
  const creds = await getStoredCredentials();
  if (creds) {
    console.log("[ServiceWorker] Found credentials, connecting...");
    const connected = await wsConnection.connect();
    await chrome.storage.local.set({ wsConnected: connected });
  }
});
(async () => {
  const creds = await getStoredCredentials();
  if (creds) {
    console.log("[ServiceWorker] Credentials found on activate, connecting...");
    const connected = await wsConnection.connect();
    await chrome.storage.local.set({ wsConnected: connected });
  }
})();
chrome.runtime.onInstalled.addListener((details) => {
  console.log("[ServiceWorker] Extension installed/updated:", details.reason);
  if (details.reason === "install") {
    chrome.tabs.create({
      url: "https://clawku.ai/?section=devices"
    });
  }
});
//# sourceMappingURL=service-worker.js.map
