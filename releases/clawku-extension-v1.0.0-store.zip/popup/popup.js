const stateLoading = document.getElementById("state-loading");
const stateUnpaired = document.getElementById("state-unpaired");
const stateConnected = document.getElementById("state-connected");
const stateDisconnected = document.getElementById("state-disconnected");
const stateError = document.getElementById("state-error");
const inputPairingCode = document.getElementById("pairing-code");
const inputApiUrl = document.getElementById("api-url");
const personaName = document.getElementById("persona-name");
const personaNameDisconnected = document.getElementById("persona-name-disconnected");
const errorText = document.getElementById("error-text");
const btnPair = document.getElementById("btn-pair");
const btnTest = document.getElementById("btn-test");
const btnDisconnect = document.getElementById("btn-disconnect");
const btnDisconnect2 = document.getElementById("btn-disconnect-2");
const btnReconnect = document.getElementById("btn-reconnect");
const btnRetry = document.getElementById("btn-retry");
function showState(state) {
  stateLoading.classList.add("hidden");
  stateUnpaired.classList.add("hidden");
  stateConnected.classList.add("hidden");
  stateDisconnected.classList.add("hidden");
  stateError.classList.add("hidden");
  switch (state) {
    case "loading":
      stateLoading.classList.remove("hidden");
      break;
    case "unpaired":
      stateUnpaired.classList.remove("hidden");
      break;
    case "connected":
      stateConnected.classList.remove("hidden");
      break;
    case "disconnected":
      stateDisconnected.classList.remove("hidden");
      break;
    case "error":
      stateError.classList.remove("hidden");
      break;
  }
}
function showError(message) {
  errorText.textContent = message;
  showState("error");
}
async function sendMessage(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      resolve(response);
    });
  });
}
async function loadStatus() {
  showState("loading");
  try {
    const status = await sendMessage({ type: "GET_STATUS" });
    if (!status.paired) {
      showState("unpaired");
      return;
    }
    if (status.connected) {
      personaName.textContent = status.personaName || "All Personas";
      showState("connected");
    } else {
      personaNameDisconnected.textContent = status.personaName || "All Personas";
      showState("disconnected");
    }
  } catch (error) {
    showError("Failed to load status");
  }
}
async function handlePair() {
  const code = inputPairingCode.value.trim();
  if (!code || code.length < 6) {
    showError("Please enter a valid 6-digit code");
    return;
  }
  const apiUrl = inputApiUrl.value.trim() || void 0;
  btnPair.textContent = "Connecting...";
  btnPair.setAttribute("disabled", "true");
  try {
    const result = await sendMessage({
      type: "PAIR",
      payload: { code, apiBaseUrl: apiUrl }
    });
    if (result.success) {
      await loadStatus();
    } else {
      showError(result.error || "Pairing failed");
    }
  } catch (error) {
    showError("Connection error");
  } finally {
    btnPair.textContent = "Connect";
    btnPair.removeAttribute("disabled");
  }
}
async function handleDisconnect() {
  try {
    await sendMessage({ type: "DISCONNECT" });
    inputPairingCode.value = "";
    showState("unpaired");
  } catch (error) {
    showError("Failed to disconnect");
  }
}
async function handleReconnect() {
  btnReconnect.textContent = "Connecting...";
  btnReconnect.setAttribute("disabled", "true");
  try {
    const result = await sendMessage({ type: "RECONNECT" });
    if (result.success) {
      await loadStatus();
    } else {
      showError(result.error || "Reconnection failed");
    }
  } catch (error) {
    showError("Connection error");
  } finally {
    btnReconnect.textContent = "Reconnect Now";
    btnReconnect.removeAttribute("disabled");
  }
}
async function handleTest() {
  btnTest.textContent = "Testing...";
  btnTest.setAttribute("disabled", "true");
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      showError("No active tab");
      return;
    }
    const response = await chrome.tabs.sendMessage(tab.id, { type: "PING" });
    if (response?.success) {
      btnTest.textContent = "Working!";
      setTimeout(() => {
        btnTest.textContent = "Test Connection";
      }, 2e3);
    } else {
      btnTest.textContent = "Test Failed";
      setTimeout(() => {
        btnTest.textContent = "Test Connection";
      }, 2e3);
    }
  } catch (error) {
    btnTest.textContent = "N/A on this page";
    setTimeout(() => {
      btnTest.textContent = "Test Connection";
    }, 2e3);
  } finally {
    btnTest.removeAttribute("disabled");
  }
}
btnPair.addEventListener("click", handlePair);
btnDisconnect.addEventListener("click", handleDisconnect);
btnDisconnect2.addEventListener("click", handleDisconnect);
btnReconnect.addEventListener("click", handleReconnect);
btnTest.addEventListener("click", handleTest);
btnRetry.addEventListener("click", loadStatus);
inputPairingCode.addEventListener("input", () => {
  inputPairingCode.value = inputPairingCode.value.toUpperCase().replace(/[^A-Z0-9]/g, "");
});
inputPairingCode.addEventListener("keypress", (e) => {
  if (e.key === "Enter") {
    handlePair();
  }
});
loadStatus();
//# sourceMappingURL=popup.js.map
